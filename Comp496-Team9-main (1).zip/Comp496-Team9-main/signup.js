document.addEventListener("DOMContentLoaded", function() {
    
    document.getElementById("signupForm").addEventListener("submit", function(event) {
        event.preventDefault(); 

        
        var username = document.getElementById("username").value.trim();
        var email = document.getElementById("email").value.trim();
        var password = document.getElementById("password").value;

        
        var errorMessage = document.getElementById("error-message");
        errorMessage.innerHTML = ""; 

        if (!username || !email || !password) {
            errorMessage.innerHTML = "Please fill in all fields.";
            return;
        }

        
        var emailRegex = /^\S+@\S+\.\S+$/;
        if (!emailRegex.test(email)) {
            errorMessage.innerHTML = "Please enter a valid email address.";
            return;
        }

        
        alert("Sign up successful! Welcome to HealthFit.");
       
        window.location.href = "signin.html";
    });
});