document.addEventListener('DOMContentLoaded', function () {
    const signinForm = document.getElementById('signinForm');

    signinForm.addEventListener('submit', function (event) {
        event.preventDefault(); 

        
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        
        const xhr = new XMLHttpRequest();
        xhr.open('POST', '/signin', true);
        xhr.setRequestHeader('Content-Type', 'application/json');

        xhr.onload = function () {
            if (xhr.status === 200) {
                
                window.location.href = 'FitnessGUI.html';
            } else {
                
                alert('Sign-in failed. Please check your username and password.');
            }
        };

        xhr.onerror = function () {
            
            alert('Error occurred while signing in. Please try again later.');
        };

        
        xhr.send(JSON.stringify({ username: username, password: password }));
    });
});