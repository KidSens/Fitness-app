document.addEventListener("DOMContentLoaded", function() {
    // Load existing posts from local storage when the page loads
    loadPosts();

    // Add event listener to the post button
    document.getElementById("postButton").addEventListener("click", function() {
        // Get the post content
        var postContent = document.getElementById("postContent").value.trim();
        
        if (postContent !== "") {
            // Create a new post object with content and timestamp
            var post = {
                content: postContent,
                timestamp: new Date().toLocaleString()
            };

            // Save the post to local storage
            savePost(post);

            // Clear the post content textarea
            document.getElementById("postContent").value = "";

            // Reload the posts to display the new post
            loadPosts();
        } else {
            alert("Please enter a post content.");
        }
    });

    // Add event listener to the Go Back button
    document.getElementById("goBackButton").addEventListener("click", function() {
        window.location.href = "fitnessGUI.html"; // Redirect to the main app page
    });
});

// Function to save a post to local storage
function savePost(post) {
    var posts = JSON.parse(localStorage.getItem("forumPosts")) || [];
    posts.push(post);
    localStorage.setItem("forumPosts", JSON.stringify(posts));
}

// Function to load and display existing posts from local storage
function loadPosts() {
    var posts = JSON.parse(localStorage.getItem("forumPosts")) || [];
    var chatBox = document.getElementById("chatBox");
    chatBox.innerHTML = ""; // Clear previous messages

    posts.forEach(function(post) {
        var messageDiv = document.createElement("div");
        messageDiv.classList.add("message");

        var headerDiv = document.createElement("div");
        headerDiv.classList.add("message-header");
        headerDiv.innerHTML = '<span class="message-timestamp">' + post.timestamp + '</span>';

        var contentDiv = document.createElement("div");
        contentDiv.classList.add("message-content");
        contentDiv.textContent = post.content;

        messageDiv.appendChild(headerDiv);
        messageDiv.appendChild(contentDiv);

        chatBox.appendChild(messageDiv);
    });
}
