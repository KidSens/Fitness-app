document.addEventListener('DOMContentLoaded', function() {
    var titleLabel = document.getElementById('titleLabel');
    var weightComboBox = document.getElementById('weightComboBox');
    var heightComboBox = document.getElementById('heightComboBox');
    var workoutTextArea = document.getElementById('workoutTextArea');
    var startButton = document.getElementById('startButton');
    var mealSuggestionTextArea = document.getElementById('mealSuggestionTextArea');
    var weightField = document.getElementById('weightField');
    var caloriesField = document.getElementById('caloriesField');
    var addMealButton = document.getElementById('addMealButton');
    var viewWorkoutButton = document.getElementById('viewWorkoutButton');
    var trackWeightButton = document.getElementById('trackWeightButton');
    var saveWorkoutButton = document.getElementById('saveWorkoutButton');
    var loadWorkoutButton = document.getElementById('loadWorkoutButton');
    var reminderTextArea = document.getElementById('reminderTextArea');
    var reminderField = document.getElementById('reminderField');
    var setReminderButton = document.getElementById('setReminderButton');
    var loggedInUserLabel = document.getElementById('loggedInUserLabel');
    var loginButton = document.getElementById('loginButton');
    var logoutButton = document.getElementById('logoutButton');

    var isLoggedIn = false;
    var loggedInUsername = '';

    loginButton.addEventListener('click', function() {
        performLogin();
    });

    logoutButton.addEventListener('click', function() {
        performLogout();
    });

    startButton.addEventListener('click', function() {
        startWorkout();
    });

    addMealButton.addEventListener('click', function() {
        addMealIntake();
    });

    viewWorkoutButton.addEventListener('click', function() {
        viewWorkout();
    });

    trackWeightButton.addEventListener('click', function() {
        trackWeight();
    });

    saveWorkoutButton.addEventListener('click', function() {
        saveWorkout();
    });

    loadWorkoutButton.addEventListener('click', function() {
        loadWorkout();
    });

    setReminderButton.addEventListener('click', function() {
        setReminder();
    });

    function performLogin() {
        var username = prompt('Enter username:');
        var password = prompt('Enter password:');
        if (username && password) {
            isLoggedIn = true;
            loggedInUsername = username;
            updateAuthenticationComponents();
            alert('Login successful!');
        } else {
            alert('Invalid username or password.');
        }
    }

    function performLogout() {
        isLoggedIn = false;
        loggedInUsername = '';
        updateAuthenticationComponents();
        alert('Logged out successfully.');
    }

    function updateAuthenticationComponents() {
        loggedInUserLabel.textContent = isLoggedIn ? 'Logged in as: ' + loggedInUsername : 'Not logged in';
        loginButton.style.display = isLoggedIn ? 'none' : 'inline-block';
        logoutButton.style.display = isLoggedIn ? 'inline-block' : 'none';
    }

    function startWorkout() {
        var selectedWeight = weightComboBox.value;
        var selectedHeight = heightComboBox.value;

        if (selectedWeight === '0' || selectedHeight === '0') {
            alert('Please select weight and height options.');
            return;
        }

        if (timer) {
            alert('Workout is already in progress.');
            return;
        }

        workoutTextArea.textContent = 'Workout started!\n';
        var timeElapsed = 0;
        var timer = setInterval(function() {
            timeElapsed++;
            workoutTextArea.textContent += 'Time Elapsed: ' + timeElapsed + ' seconds\n';
        }, 1000);

        startButton.disabled = true;
    }

    function addMealIntake() {
        var weight = weightField.value;
        var calories = caloriesField.value;
        if (weight === '' || calories === '') {
            alert('Please enter weight and calories.');
            return;
        }
        mealSuggestionTextArea.textContent += 'Weight: ' + weight + ' kg, Calories: ' + calories + '\n';
        weightField.value = '';
        caloriesField.value = '';
    }

    function viewWorkout() {
        alert(workoutTextArea.textContent);
    }

    function trackWeight() {
        var selectedWeight = weightComboBox.value;
        if (selectedWeight !== '0') {
            workoutTextArea.textContent += 'Weight Tracked: ' + selectedWeight + '\n';
        }
    }

    function saveWorkout() {
        var workoutHistory = workoutTextArea.textContent;
        // Perform save operation (e.g., send data to server or save locally)
        alert('Workout history saved successfully.');
    }

    function loadWorkout() {
        // Perform load operation (e.g., fetch data from server or load from local storage)
        var workoutHistory = 'Load previous workout history here...\n';
        workoutTextArea.textContent = workoutHistory;
        alert('Workout history loaded successfully.');
    }

    function setReminder() {
        var reminderText = reminderField.value;
        if (reminderText !== '') {
            reminderTextArea.textContent += 'Reminder set for ' + getCurrentTime() + ': ' + reminderText + '\n';
            reminderField.value = '';
        }
    }

    function getCurrentTime() {
        var now = new Date();
        var hours = now.getHours().toString().padStart(2, '0');
        var minutes = now.getMinutes().toString().padStart(2, '0');
        return hours + ':' + minutes;
    }
});